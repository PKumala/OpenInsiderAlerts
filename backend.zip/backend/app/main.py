from fastapi import FastAPI
from app.db.base import Base
from app.db.engine import engine, wait_for_db

app = FastAPI()


@app.on_event("startup")
def startup():
    wait_for_db()
    Base.metadata.create_all(bind=engine)
